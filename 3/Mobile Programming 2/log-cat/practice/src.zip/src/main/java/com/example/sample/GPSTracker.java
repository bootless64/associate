package com.example.sample;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

public class GPSTracker extends Service implements LocationListener{
    private Context context;
    private LocationManager LocationManger;
    private Location location;
    private double latitude=0.0,longitude=0.0;
    private boolean isGPSEnable=false,isNetworkEnabled=false,canGetLocation=false;
    public static final int TIME_BW_UPDATES=1000*10,MIN_DISTANCE_FOR_UPDATE=10;

    public GPSTracker(Context context) {
        this.context = context;
        getLocation();
    }
    public Location getLocation() throws SecurityException{
        LocationManger=(LocationManager) context.getSystemService(context.LOCATION_SERVICE);
        isGPSEnable=LocationManger.isProviderEnabled(LocationManager.GPS_PROVIDER);
        isNetworkEnabled=LocationManger.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        if(!isGPSEnable&&!isNetworkEnabled)
            canGetLocation=false;
        else{
            canGetLocation=true;
            if(!hasPermissions()){
                location=null;
                return location;
            }
            if(isNetworkEnabled){
                LocationManger.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,TIME_BW_UPDATES,MIN_DISTANCE_FOR_UPDATE,this);
                if(LocationManger!=null){
                    location=LocationManger.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    if(location!=null){
                        latitude=location.getLatitude();
                        longitude=location.getLongitude();
                    }
                }
            }
            if (isGPSEnable&&location==null) {
                LocationManger.requestLocationUpdates(LocationManager.GPS_PROVIDER, TIME_BW_UPDATES, MIN_DISTANCE_FOR_UPDATE, this);
                if (LocationManger != null) {
                    location = LocationManger.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                    if (location != null) {
                        latitude = location.getLatitude();
                        longitude = location.getLongitude();
                    }
                }
            }
        }
        return location;
    }

    public double getLatitude() {
        if(location!=null)
            latitude=location.getLatitude();
        return latitude;
    }

    public double getLongitude() {
        if(location!=null)
            latitude=location.getLongitude();
        return longitude;
    }

    public boolean isCanGetLocation() {return canGetLocation;}
    public boolean hasPermissions(){
        return (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED);
    }
    public void showGPSAlertDialog(){
        AlertDialog.Builder builder=new AlertDialog.Builder(context);
        builder.setTitle("GPS").setMessage("GPS isn't enable.Do you want to go to setting menu!!")
                .setPositiveButton("Settings", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent=new Intent();
                        intent.setAction(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        context.startActivity(intent);
                    }
                })
                .setNegativeButton("Cansel",new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }
    public void stopUsingGPS()throws SecurityException{
        if(LocationManger!=null&&hasPermissions())
            LocationManger.removeUpdates(this);
    }
    @Override
    public void onLocationChanged(Location location){
        if(location!=null){
            Log.i(GPSTracker.class.getSimpleName(),"lat"+location.getLatitude()+", lon: "+location.getLongitude());
        }else{
            Log.i(GPSTracker.class.getSimpleName(),"location=null");

        }

    }
    public void onStatusChanged(String s, int i, Bundle bundle){

    }
    @Override
    public void onProviderEnabled(String provider){
        Log.i(GPSTracker.class.getSimpleName(),"provider enabled : " +provider);
    }
    @Override
    public void onProviderDisabled(String provider){
        Log.i(GPSTracker.class.getSimpleName(),"provider disabled : " + provider);
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent){return null;}
}
