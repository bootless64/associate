package com.example.sample;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQ_CODE=1234;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkPermissions();
    }

    private void checkPermissions() {
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},PERMISSION_REQ_CODE);
        }
    }

    @Override
    protected void onResume(){super.onResume();}

    public void onRequestPermissionResult(int requestcode, @NonNull String[] permissions,@NonNull int[] grantResults){
        super.onRequestPermissionsResult(requestcode,permissions,grantResults);
        if(grantResults[0]==PackageManager.PERMISSION_GRANTED){
            Toast.makeText(this,"Permission granted ",Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this,"Permission denied to access location ",Toast.LENGTH_SHORT).show();
        }
    }
    public void onclick(View v){
        GPSTracker gpsTracker=new GPSTracker(this);
        if(gpsTracker.isCanGetLocation()){
            double lat=gpsTracker.getLatitude();
            double lon=gpsTracker.getLongitude();
            Toast.makeText(this,"Your Location is: \n latitude:  "+lat+"\n longitude: "+lon ,Toast.LENGTH_SHORT).show();

        }
    }

}